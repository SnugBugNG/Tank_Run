gdjs._49Code = {};
gdjs._49Code.GDSteveObjects1_1final = [];

gdjs._49Code.GDBrickObjects1= [];
gdjs._49Code.GDBrickObjects2= [];
gdjs._49Code.GDSpikeObjects1= [];
gdjs._49Code.GDSpikeObjects2= [];
gdjs._49Code.GDSteveObjects1= [];
gdjs._49Code.GDSteveObjects2= [];
gdjs._49Code.GDspeedObjects1= [];
gdjs._49Code.GDspeedObjects2= [];
gdjs._49Code.GDwinObjects1= [];
gdjs._49Code.GDwinObjects2= [];

gdjs._49Code.conditionTrue_0 = {val:false};
gdjs._49Code.condition0IsTrue_0 = {val:false};
gdjs._49Code.condition1IsTrue_0 = {val:false};
gdjs._49Code.condition2IsTrue_0 = {val:false};
gdjs._49Code.condition3IsTrue_0 = {val:false};
gdjs._49Code.conditionTrue_1 = {val:false};
gdjs._49Code.condition0IsTrue_1 = {val:false};
gdjs._49Code.condition1IsTrue_1 = {val:false};
gdjs._49Code.condition2IsTrue_1 = {val:false};
gdjs._49Code.condition3IsTrue_1 = {val:false};


gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDSteveObjects1Objects = Hashtable.newFrom({"Steve": gdjs._49Code.GDSteveObjects1});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDSpikeObjects1Objects = Hashtable.newFrom({"Spike": gdjs._49Code.GDSpikeObjects1});
gdjs._49Code.asyncCallback9395164 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}{runtimeScene.getGame().getVariables().get("Death Count").add(1);
}}
gdjs._49Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs._49Code.asyncCallback9395164(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs._49Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Spike"), gdjs._49Code.GDSpikeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Steve"), gdjs._49Code.GDSteveObjects1);

gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDSteveObjects1Objects, gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDSpikeObjects1Objects, false, runtimeScene, false);
}if (gdjs._49Code.condition0IsTrue_0.val) {
/* Reuse gdjs._49Code.GDSteveObjects1 */
{for(var i = 0, len = gdjs._49Code.GDSteveObjects1.length ;i < len;++i) {
    gdjs._49Code.GDSteveObjects1[i].pauseAnimation();
}
}{for(var i = 0, len = gdjs._49Code.GDSteveObjects1.length ;i < len;++i) {
    gdjs._49Code.GDSteveObjects1[i].activateBehavior("PlatformerObject", false);
}
}
{ //Subevents
gdjs._49Code.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDSteveObjects1Objects = Hashtable.newFrom({"Steve": gdjs._49Code.GDSteveObjects1});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDspeedObjects1Objects = Hashtable.newFrom({"speed": gdjs._49Code.GDspeedObjects1});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDSteveObjects1Objects = Hashtable.newFrom({"Steve": gdjs._49Code.GDSteveObjects1});
gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDwinObjects1Objects = Hashtable.newFrom({"win": gdjs._49Code.GDwinObjects1});
gdjs._49Code.eventsList2 = function(runtimeScene) {

{


gdjs._49Code.eventsList1(runtimeScene);
}


{

gdjs._49Code.GDSteveObjects1.length = 0;


gdjs._49Code.condition0IsTrue_0.val = false;
{
{gdjs._49Code.conditionTrue_1 = gdjs._49Code.condition0IsTrue_0;
gdjs._49Code.GDSteveObjects1_1final.length = 0;gdjs._49Code.condition0IsTrue_1.val = false;
gdjs._49Code.condition1IsTrue_1.val = false;
gdjs._49Code.condition2IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Steve"), gdjs._49Code.GDSteveObjects2);
for(var i = 0, k = 0, l = gdjs._49Code.GDSteveObjects2.length;i<l;++i) {
    if ( gdjs._49Code.GDSteveObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs._49Code.condition0IsTrue_1.val = true;
        gdjs._49Code.GDSteveObjects2[k] = gdjs._49Code.GDSteveObjects2[i];
        ++k;
    }
}
gdjs._49Code.GDSteveObjects2.length = k;if( gdjs._49Code.condition0IsTrue_1.val ) {
    gdjs._49Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs._49Code.GDSteveObjects2.length;j<jLen;++j) {
        if ( gdjs._49Code.GDSteveObjects1_1final.indexOf(gdjs._49Code.GDSteveObjects2[j]) === -1 )
            gdjs._49Code.GDSteveObjects1_1final.push(gdjs._49Code.GDSteveObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Steve"), gdjs._49Code.GDSteveObjects2);
for(var i = 0, k = 0, l = gdjs._49Code.GDSteveObjects2.length;i<l;++i) {
    if ( gdjs._49Code.GDSteveObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs._49Code.condition1IsTrue_1.val = true;
        gdjs._49Code.GDSteveObjects2[k] = gdjs._49Code.GDSteveObjects2[i];
        ++k;
    }
}
gdjs._49Code.GDSteveObjects2.length = k;if( gdjs._49Code.condition1IsTrue_1.val ) {
    gdjs._49Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs._49Code.GDSteveObjects2.length;j<jLen;++j) {
        if ( gdjs._49Code.GDSteveObjects1_1final.indexOf(gdjs._49Code.GDSteveObjects2[j]) === -1 )
            gdjs._49Code.GDSteveObjects1_1final.push(gdjs._49Code.GDSteveObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Steve"), gdjs._49Code.GDSteveObjects2);
for(var i = 0, k = 0, l = gdjs._49Code.GDSteveObjects2.length;i<l;++i) {
    if ( gdjs._49Code.GDSteveObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs._49Code.condition2IsTrue_1.val = true;
        gdjs._49Code.GDSteveObjects2[k] = gdjs._49Code.GDSteveObjects2[i];
        ++k;
    }
}
gdjs._49Code.GDSteveObjects2.length = k;if( gdjs._49Code.condition2IsTrue_1.val ) {
    gdjs._49Code.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs._49Code.GDSteveObjects2.length;j<jLen;++j) {
        if ( gdjs._49Code.GDSteveObjects1_1final.indexOf(gdjs._49Code.GDSteveObjects2[j]) === -1 )
            gdjs._49Code.GDSteveObjects1_1final.push(gdjs._49Code.GDSteveObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs._49Code.GDSteveObjects1_1final, gdjs._49Code.GDSteveObjects1);
}
}
}if (gdjs._49Code.condition0IsTrue_0.val) {
/* Reuse gdjs._49Code.GDSteveObjects1 */
{for(var i = 0, len = gdjs._49Code.GDSteveObjects1.length ;i < len;++i) {
    gdjs._49Code.GDSteveObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Steve"), gdjs._49Code.GDSteveObjects1);

gdjs._49Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDSteveObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDSteveObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDSteveObjects1[k] = gdjs._49Code.GDSteveObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDSteveObjects1.length = k;}if (gdjs._49Code.condition0IsTrue_0.val) {
/* Reuse gdjs._49Code.GDSteveObjects1 */
{for(var i = 0, len = gdjs._49Code.GDSteveObjects1.length ;i < len;++i) {
    gdjs._49Code.GDSteveObjects1[i].setAnimationName("run");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Steve"), gdjs._49Code.GDSteveObjects1);

gdjs._49Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._49Code.GDSteveObjects1.length;i<l;++i) {
    if ( gdjs._49Code.GDSteveObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs._49Code.condition0IsTrue_0.val = true;
        gdjs._49Code.GDSteveObjects1[k] = gdjs._49Code.GDSteveObjects1[i];
        ++k;
    }
}
gdjs._49Code.GDSteveObjects1.length = k;}if (gdjs._49Code.condition0IsTrue_0.val) {
/* Reuse gdjs._49Code.GDSteveObjects1 */
{for(var i = 0, len = gdjs._49Code.GDSteveObjects1.length ;i < len;++i) {
    gdjs._49Code.GDSteveObjects1[i].setAnimationName("jump");
}
}}

}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Death count")) == 5;
}if (gdjs._49Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "death", false);
}}

}


{


{
}

}


{


gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._49Code.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("speed"), gdjs._49Code.GDspeedObjects1);
gdjs.copyArray(runtimeScene.getObjects("win"), gdjs._49Code.GDwinObjects1);
{for(var i = 0, len = gdjs._49Code.GDspeedObjects1.length ;i < len;++i) {
    gdjs._49Code.GDspeedObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._49Code.GDwinObjects1.length ;i < len;++i) {
    gdjs._49Code.GDwinObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Steve"), gdjs._49Code.GDSteveObjects1);
gdjs.copyArray(runtimeScene.getObjects("speed"), gdjs._49Code.GDspeedObjects1);

gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDSteveObjects1Objects, gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDspeedObjects1Objects, false, runtimeScene, false);
}if (gdjs._49Code.condition0IsTrue_0.val) {
/* Reuse gdjs._49Code.GDSteveObjects1 */
{for(var i = 0, len = gdjs._49Code.GDSteveObjects1.length ;i < len;++i) {
    gdjs._49Code.GDSteveObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(gdjs._49Code.GDSteveObjects1[i].getBehavior("PlatformerObject").getMaxSpeed() + (10000));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Steve"), gdjs._49Code.GDSteveObjects1);
gdjs.copyArray(runtimeScene.getObjects("win"), gdjs._49Code.GDwinObjects1);

gdjs._49Code.condition0IsTrue_0.val = false;
{
gdjs._49Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDSteveObjects1Objects, gdjs._49Code.mapOfGDgdjs_46_9549Code_46GDwinObjects1Objects, false, runtimeScene, false);
}if (gdjs._49Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}}

}


};

gdjs._49Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._49Code.GDBrickObjects1.length = 0;
gdjs._49Code.GDBrickObjects2.length = 0;
gdjs._49Code.GDSpikeObjects1.length = 0;
gdjs._49Code.GDSpikeObjects2.length = 0;
gdjs._49Code.GDSteveObjects1.length = 0;
gdjs._49Code.GDSteveObjects2.length = 0;
gdjs._49Code.GDspeedObjects1.length = 0;
gdjs._49Code.GDspeedObjects2.length = 0;
gdjs._49Code.GDwinObjects1.length = 0;
gdjs._49Code.GDwinObjects2.length = 0;

gdjs._49Code.eventsList2(runtimeScene);

return;

}

gdjs['_49Code'] = gdjs._49Code;
