gdjs.deathCode = {};
gdjs.deathCode.GDNewSpriteObjects1= [];
gdjs.deathCode.GDNewSpriteObjects2= [];

gdjs.deathCode.conditionTrue_0 = {val:false};
gdjs.deathCode.condition0IsTrue_0 = {val:false};
gdjs.deathCode.condition1IsTrue_0 = {val:false};


gdjs.deathCode.asyncCallback9454900 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "1", false);
}{runtimeScene.getGame().getVariables().get("Death count").setNumber(0);
}}
gdjs.deathCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.deathCode.asyncCallback9454900(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.deathCode.eventsList1 = function(runtimeScene) {

{


gdjs.deathCode.condition0IsTrue_0.val = false;
{
gdjs.deathCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.deathCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.deathCode.GDNewSpriteObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.deathCode.GDNewSpriteObjects1.length !== 0 ? gdjs.deathCode.GDNewSpriteObjects1[0] : null), true, "", 0);
}}

}


{


gdjs.deathCode.condition0IsTrue_0.val = false;
{
gdjs.deathCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.deathCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.deathCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.deathCode.condition0IsTrue_0.val = false;
{
gdjs.deathCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.deathCode.condition0IsTrue_0.val) {
}

}


};

gdjs.deathCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.deathCode.GDNewSpriteObjects1.length = 0;
gdjs.deathCode.GDNewSpriteObjects2.length = 0;

gdjs.deathCode.eventsList1(runtimeScene);

return;

}

gdjs['deathCode'] = gdjs.deathCode;
